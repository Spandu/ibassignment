var ibasgmnt=angular.module('ibasgmnt', ['ngRoute']);
ibasgmnt.config(function($routeProvider) {
	$routeProvider
	.when("/features-components",{
		templateUrl:"features-components.html"
	})
	.when("/blog-rightsidebar",{
		templateUrl:"blog-rightsidebar.html"
	})
	.when("/home",{
		templateUrl:"home.html"
	})
	.otherwise("/home");
});